$(function () {

    $('div.carousel').slider();

});